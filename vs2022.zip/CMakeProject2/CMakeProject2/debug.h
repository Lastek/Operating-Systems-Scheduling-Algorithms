#include <queue>
#include <iostream>
#ifndef __TYPES_H
#include "types.h"
#endif

void test_fcfs_queue(const std::queue<proc_data_t> &q);
